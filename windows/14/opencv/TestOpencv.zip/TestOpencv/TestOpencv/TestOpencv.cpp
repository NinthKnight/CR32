// TestOpencv.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <string>
#include <opencv2\opencv.hpp>
#include <sstream>
using namespace std;

#ifdef _DEBUG

#pragma comment(lib, "opencv_highgui342d.lib")
#pragma comment(lib, "opencv_imgcodecs342d.lib")
#pragma comment(lib, "opencv_imgproc342d.lib")
#pragma comment(lib, "opencv_core342d.lib")
#else
#pragma comment(lib, "opencv_highgui342.lib")
#pragma comment(lib, "opencv_imgcodecs342.lib")
#pragma comment(lib, "opencv_imgproc342.lib")
#pragma comment(lib, "opencv_core342.lib")
#endif
//#pragma comment(lib, "opencv_aruco342.lib")
//#pragma comment(lib, "opencv_bgsegm342.lib")
//#pragma comment(lib, "opencv_bioinspired342.lib")
//#pragma comment(lib, "opencv_calib3d342.lib")
//#pragma comment(lib, "opencv_ccalib342.lib")
//#pragma comment(lib, "opencv_datasets342.lib")
//
//#pragma comment(lib, "opencv_dnn_objdetect342.lib")
//#pragma comment(lib, "opencv_dnn342.lib")
//#pragma comment(lib, "opencv_dpm342.lib")
//#pragma comment(lib, "opencv_face342.lib")
//#pragma comment(lib, "opencv_features2d342.lib")
//#pragma comment(lib, "opencv_flann342.lib")
//#pragma comment(lib, "opencv_fuzzy342.lib")
//#pragma comment(lib, "opencv_hfs342.lib")
//#pragma comment(lib, "opencv_img_hash342.lib")
//#pragma comment(lib, "opencv_line_descriptor342.lib")
//
//#pragma comment(lib, "opencv_ml342.lib")
//#pragma comment(lib, "opencv_objdetect342.lib")
//#pragma comment(lib, "opencv_optflow342.lib")
//#pragma comment(lib, "opencv_phase_unwrapping342.lib")
//#pragma comment(lib, "opencv_photo342.lib")
//#pragma comment(lib, "opencv_plot342.lib")
//#pragma comment(lib, "opencv_reg342.lib")
//#pragma comment(lib, "opencv_rgbd342.lib")
//#pragma comment(lib, "opencv_saliency342.lib")
//#pragma comment(lib, "opencv_shape342.lib")
//#pragma comment(lib, "opencv_stereo342.lib")
//#pragma comment(lib, "opencv_stitching342.lib")
//#pragma comment(lib, "opencv_structured_light342.lib")
//#pragma comment(lib, "opencv_superres342.lib")
//
//#pragma comment(lib, "opencv_surface_matching342.lib")
//#pragma comment(lib, "opencv_text342.lib")
//#pragma comment(lib, "opencv_tracking342.lib")
//#pragma comment(lib, "opencv_video342.lib")
//#pragma comment(lib, "opencv_videoio342.lib")
//#pragma comment(lib, "opencv_videostab342.lib")
//#pragma comment(lib, "opencv_xfeatures2d342.lib")
//#pragma comment(lib, "opencv_ximgproc342.lib")
//
//#pragma comment(lib, "opencv_xobjdetect342.lib")
//#pragma comment(lib, "opencv_xphoto342.lib")

//Ѱ�����ƥ��λ�õķ���
//����1:	Դͼ��
//����2:	ģ��ͼ��
//����:	�õ������ƥ���
//
int MatchTemplate(string soucreFile, string templateFile)
{
	cv::Mat imageSource = cv::imread(soucreFile.c_str(),
		cv::IMREAD_UNCHANGED);
	cv::Mat imageTemplate = cv::imread(templateFile.c_str(),
		cv::IMREAD_UNCHANGED);
	cv::Mat imageMatched;

	////ģ��ƥ��
	cv::matchTemplate(imageSource, imageTemplate, imageMatched,
		cv::TM_CCOEFF_NORMED);

	double minVal, maxVal;
	cv::Point minLoc, maxLoc;
	//Ѱ�����ƥ��λ��
	cv::minMaxLoc(imageMatched, &minVal, &maxVal, &minLoc, &maxLoc);

	//cv::Mat imageColor;
	//cv::cvtColor(imageSource, imageColor, CV_BGR2BGRA);
	//cv::rectangle(imageColor, cv::Point(maxLoc.x, maxLoc.y),
	//	cv::Point(maxLoc.x + imageTemplate.cols, maxLoc.y + imageTemplate.rows),
	//	(7, 249, 151), 2);

	////����һ���´���
	//std::string windowName = "TestOpencv";
	////��ͼ����ʾ���´����Ĵ�����
	//cv::namedWindow(windowName, CV_WINDOW_AUTOSIZE);
	//cv::imshow(windowName, imageSource);
	//cv::imshow(windowName, imageMatched);
	//cv::imshow(windowName, imageColor);
	//qDebug() << "maxLoc.x = " << maxLoc.x << ",maxLoc.y = " << maxLoc.y << endl;
	
	stringstream ss;
	ss << "maxLoc.x = " << maxLoc.x << ",maxLoc.y = " << maxLoc.y << endl;
	
	return 1;
}

int main()
{
	MatchTemplate("D:\\1.jpg", "D:\\3.jpg");

	system("pause");
    return 0;
}

